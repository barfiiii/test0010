#4. Create and store a vector that contains, in any configuration, 
#the following:
#i. A sequence of integers from 6 to 12 (inclusive)
s1<-seq(6,12)
print(s1)
#ii. A threefold repetition of the value 5.3
s2<-rep(5.3,times=3)
print(s2)
#iii. The number -3
s3<-(-3)
print(s3)
#iv. A sequence of nine values starting at 102 and ending at the number that is 
#the total length of the vector created in (3.)
len<-50
s4<-seq(102,50,length=9)
print(s4)        

