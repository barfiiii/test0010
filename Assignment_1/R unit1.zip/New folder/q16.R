#16. Use the vector c(2,4,6) and the vector c(1,2) in conjunction with rep and * to produce the
#vector c(2,4,6,4,8,12).
vec16 <- c(c(2,4,6) * c(1,2))
print(vec16)
