#1. Create and store a sequence of values from 5 to -11 that progresses in steps of 0.3.
a<-seq(5,-11,-0.3)
print(a)